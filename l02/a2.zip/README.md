# L02

Theodore Peters 260919785

`./L02 ../resources/`

PCF was implemented, along with Poisson Sampling.

There was also a bug in the provided code where it was trying to load "Sphere.obj" instead of the correct filename "sphere.obj", which was fixed.

Also, the lightPos used was updated to reflect the correct light position when viewed from the camera; I am not sure whether this is part of the assignment as I don't think it was mentioned in one of the steps but the light looked weird otherwise.